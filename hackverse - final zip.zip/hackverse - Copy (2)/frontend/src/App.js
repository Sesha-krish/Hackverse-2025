import React, { useState, useEffect } from "react";
import Web3 from "web3";
import axios from "axios";
import ConnectWallet from "./components/ConnectWallet";
import TradeCard from "./components/TradeCard";
import StockChart from "./components/StockChart";
import BackgroundBeams from "./components/BackgroundBeams";
import "./styles.css";

const App = () => {
    const [web3, setWeb3] = useState(null);
    const [account, setAccount] = useState(null);
    const [tradeSuggestions, setTradeSuggestions] = useState([]);
    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");

    useEffect(() => {
        loadWeb3();
    }, []);

    const loadWeb3 = async () => {
        if (window.ethereum) {
            try {
                await window.ethereum.request({ method: "eth_requestAccounts" });
                const web3Instance = new Web3(window.ethereum);
                setWeb3(web3Instance);
                const accounts = await web3Instance.eth.getAccounts();
                setAccount(accounts[0]);
            } catch (error) {
                setErrorMessage("Error accessing MetaMask. Please check your wallet.");
                console.error("Error accessing MetaMask:", error);
            }
        } else {
            setErrorMessage("MetaMask is not installed! Please install it to continue.");
            console.log("MetaMask not detected.");
        }
    };

    const fetchTradeSuggestions = async () => {
        setLoading(true);
        setErrorMessage("");
        try {
            const response = await axios.get("http://127.0.0.1:5000/suggest/BTC");
            setTradeSuggestions([response.data]);
        } catch (error) {
            setErrorMessage("Error fetching trade suggestions. Is the backend running?");
            console.error("Error fetching trade suggestions:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container">
            <BackgroundBeams />
            <h1>Reinforcement Learning Trading Bot</h1>
            <ConnectWallet web3={web3} account={account} />
            <button className="fetch-button" onClick={fetchTradeSuggestions} disabled={loading}>
                {loading ? "Loading..." : "Get Trade Suggestions"}
            </button>

            {errorMessage && <p className="error">{errorMessage}</p>}

            <div className="trade-list">
                {tradeSuggestions.length > 0 ? (
                    tradeSuggestions.map((trade, index) => <TradeCard key={index} symbol={trade.symbol} />)
                ) : (
                    <p>No trade suggestions available.</p>
                )}
            </div>

            <StockChart symbol="BTC" /> {/* Pass the stock symbol here */}
        </div>
    );
};

export default App;