import { ethers } from "ethers";

// Load environment variables
const infuraUrl = process.env.REACT_APP_INFURA_URL;
const privateKey = process.env.REACT_APP_PRIVATE_KEY;

// Validate environment variables
if (!infuraUrl) {
    console.error("Missing REACT_APP_INFURA_URL in .env file");
}
if (!privateKey) {
    console.error("Missing REACT_APP_PRIVATE_KEY in .env file");
}

let provider;
let signer;

// Check if MetaMask is installed
if (window.ethereum) {
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();
} else if (infuraUrl) {
    provider = new ethers.providers.JsonRpcProvider(infuraUrl);
    signer = new ethers.Wallet(privateKey, provider);
} else {
    console.error("No Web3 provider found.");
}

export { provider, signer };