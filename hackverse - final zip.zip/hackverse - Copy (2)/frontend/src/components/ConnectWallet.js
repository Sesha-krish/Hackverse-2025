import React, { useState } from "react";

const ConnectWallet = () => {
    const [account, setAccount] = useState(null);

    const connectWallet = async () => {
        if (typeof window.ethereum !== "undefined") {
            try {
                const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
                setAccount(accounts[0]);
            } catch (error) {
                console.error("Error connecting to MetaMask:", error);
                alert("Failed to connect MetaMask. Please check your wallet.");
            }
        } else {
            alert("MetaMask not installed! Please install it to continue.");
        }
    };

    return (
        <div>
            <button onClick={connectWallet}>Connect Metamask</button>
            {account && <p>Connected: {account}</p>}
        </div>
    );
};

export default ConnectWallet;