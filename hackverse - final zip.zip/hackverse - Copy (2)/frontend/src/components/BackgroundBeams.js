import React from "react";
import { motion } from "framer-motion";
import { cn } from "../lib/utils"; // Ensure you have this utility function

const paths = [
    "M-380 -189C-380 -189 -312 216 152 343C616 470 684 875 684 875",
    "M-373 -197C-373 -197 -305 208 159 335C623 462 691 867 691 867",
    // Add more paths as needed
];

const BackgroundBeams = ({ className }) => {
    return (
        <div className={cn("absolute inset-0 flex h-full w-full items-center justify-center [mask-repeat:no-repeat] [mask-size:40px]", className)}>
            <svg
                className="pointer-events-none absolute z-0 h-full w-full"
                width="100%"
                height="100%"
                viewBox="0 0 696 316"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
            >
                {paths.map((path, index) => (
                    <motion.path
                        key={`path-${index}`}
                        d={path}
                        stroke={`url(#linearGradient-${index})`}
                        strokeOpacity="0.4"
                        strokeWidth="0.5"
                    />
                ))}
                <defs>
                    {paths.map((path, index) => (
                        <motion.linearGradient
                            id={`linearGradient-${index}`}
                            key={`gradient-${index}`}
                            initial={{
                                x1: "0%",
                                x2: "0%",
                                y1: "0%",
                                y2: "0%",
                            }}
                            animate={{
                                x1: ["0%", "100%"],
                                x2: ["0%", "95%"],
                                y1: ["0%", "100%"],
                                y2: ["0%", `${93 + Math.random() * 8}%`],
                            }}
                            transition={{
                                duration: Math.random() * 10 + 10,
                                ease: "easeInOut",
                                repeat: Infinity,
                                delay: Math.random() * 10,
                            }}
                        >
                            <stop stopColor="#18CCFC" stopOpacity="0" />
                            <stop stopColor="#18CCFC" />
                            <stop offset="32.5%" stopColor="#6344F5" />
                            <stop offset="100%" stopColor="#AE48FF" stopOpacity="0" />
                        </motion.linearGradient>
                    ))}
                </defs>
            </svg>
        </div>
    );
};

export default BackgroundBeams;