import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import axios from "axios";

const StockChart = ({ symbol }) => {
    const [historicalData, setHistoricalData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchHistoricalData = async () => {
            try {
                const response = await axios.get(`http://127.0.0.1:5000/historical/${symbol}`);
                if (response.data.error) {
                    setError(response.data.error);
                } else {
                    const data = response.data.map((entry) => ({
                        date: new Date(entry.Date).toLocaleDateString(),
                        price: entry.Close,
                    }));
                    setHistoricalData(data);
                }
                setLoading(false);
            } catch (err) {
                setError("Failed to fetch historical data. Please try again.");
                setLoading(false);
                console.error("Error fetching historical data:", err);
            }
        };

        fetchHistoricalData();
    }, [symbol]);

    if (loading) {
        return <p>Loading historical data...</p>;
    }

    if (error) {
        return <p className="text-red-500">{error}</p>;
    }

    return (
        <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold">{symbol} Historical Performance</h3>
            <LineChart width={600} height={300} data={historicalData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="price" stroke="#8884d8" />
            </LineChart>
        </div>
    );
};

export default StockChart;