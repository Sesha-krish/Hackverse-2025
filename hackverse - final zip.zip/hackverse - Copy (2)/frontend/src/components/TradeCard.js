import React, { useState } from "react";

const TradeCard = ({ symbol }) => {
    const [suggestion, setSuggestion] = useState(null);
    const [error, setError] = useState(null);

    const fetchSuggestion = async () => {
        try {
            const response = await fetch(`http://127.0.0.1:5000/suggest/${symbol}`);
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const data = await response.json();
            if (data.error) {
                setError(data.error);
            } else {
                setSuggestion(data.suggestion);
            }
        } catch (error) {
            setError("Failed to fetch trade suggestion. Please try again.");
            console.error("Error fetching suggestion:", error);
        }
    };

    return (
        <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold">{symbol}</h3>
            <button
                onClick={fetchSuggestion}
                className="mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
                Get Trade Suggestion
            </button>
            {error && <p className="text-red-500 mt-2">{error}</p>}
            {suggestion && (
                <p className="mt-2">
                    Suggestion: <span className="font-bold">{suggestion}</span>
                </p>
            )}
        </div>
    );
};

export default TradeCard;