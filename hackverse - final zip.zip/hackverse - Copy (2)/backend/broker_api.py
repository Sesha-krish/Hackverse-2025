import requests
import os
from dotenv import load_dotenv

load_dotenv()

ALPHA_VANTAGE_API_KEY = os.getenv("ALPHA_VANTAGE_API_KEY")

def get_stock_price(symbol):
    """Fetch real-time stock price using Alpha Vantage API."""
    url = f"https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={symbol}&interval=1min&apikey={ALPHA_VANTAGE_API_KEY}"
    print(f"Fetching stock price for {symbol} from Alpha Vantage...")
    response = requests.get(url)
    data = response.json()
    
    if "Time Series (1min)" in data:
        latest_time = next(iter(data["Time Series (1min)"]))
        latest_price = data["Time Series (1min)"][latest_time]["1. open"]
        print(f"Latest price for {symbol}: {latest_price}")
        return float(latest_price)
    else:
        print(f"Error fetching price: {data}")
        raise ValueError(f"Error fetching price: {data}")

def get_historical_data(symbol, period="1mo"):
    """Fetch historical stock data using Alpha Vantage API."""
    url = f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&apikey={ALPHA_VANTAGE_API_KEY}"
    print(f"Fetching historical data for {symbol} from Alpha Vantage...")
    response = requests.get(url)
    data = response.json()
    
    if "Time Series (Daily)" in data:
        historical_data = []
        for date, values in data["Time Series (Daily)"].items():
            historical_data.append({
                "Date": date,
                "Open": float(values["1. open"]),
                "High": float(values["2. high"]),
                "Low": float(values["3. low"]),
                "Close": float(values["4. close"]),
                "Volume": int(values["5. volume"]),
            })
        print(f"Fetched {len(historical_data)} days of historical data for {symbol}")
        return historical_data
    else:
        print(f"Error fetching historical data: {data}")
        raise ValueError(f"Error fetching historical data: {data}")