import pandas as pd
import joblib
import numpy as np
from stable_baselines3 import PPO

# Load trained model & scaler
model = PPO.load("trained_models/ppo_trading_bot")
scaler = joblib.load("trained_models/scaler.pkl")

# Expected feature names from training
expected_features = ["Open", "High", "Low", "Close", "VWAP", "Volume", "Turnover", "%Deliverble"]

def preprocess_input(data):
    """Ensure input data is formatted correctly before feeding into the model."""
    df = pd.DataFrame([data], columns=expected_features)
    df = scaler.transform(df)
    return df

def predict_trade(data):
    """Preprocess input and predict trade action."""
    try:
        processed_data = preprocess_input(data)
        action, _ = model.predict(processed_data)
        action = int(action)  # Ensure action is an integer
        return ["Sell", "Hold", "Buy"][action]
    except Exception as e:
        print(f"Error predicting trade: {e}")
        return "Hold"  # Default to "Hold" if there's an error