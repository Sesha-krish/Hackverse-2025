import gym
import pandas as pd
import numpy as np
from gym import spaces
from stable_baselines3 import PPO
import joblib
from sklearn.preprocessing import StandardScaler

# Load dataset
df = pd.read_csv("infy_stock.csv")
df["Date"] = pd.to_datetime(df["Date"])

# Select features for training
features = ["Open", "High", "Low", "Close", "VWAP", "Volume", "Turnover", "%Deliverble"]
scaler = StandardScaler()
df[features] = scaler.fit_transform(df[features])

# Save scaler for later use in inference
joblib.dump(scaler, "trained_models/scaler.pkl")

class StockTradingEnv(gym.Env):
    def __init__(self, df):
        super(StockTradingEnv, self).__init__()
        self.df = df
        self.current_step = 0

        # Observation space (8 features)
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(len(features),), dtype=np.float32)

        # Action space: 0 = Sell, 1 = Hold, 2 = Buy
        self.action_space = spaces.Discrete(3)

        # Initial balance
        self.balance = 10000  # $10,000
        self.shares_held = 0
        self.net_worth = self.balance

    def step(self, action):
        self.current_step += 1
        done = self.current_step >= len(self.df) - 1

        # Get stock price at current step
        current_price = self.df.iloc[self.current_step]["Close"]

        # Reward system
        reward = 0
        if action == 0:  # Sell
            if self.shares_held > 0:
                self.balance += self.shares_held * current_price
                reward = self.shares_held * (current_price - self.df.iloc[self.current_step - 1]["Close"])
                self.shares_held = 0
        elif action == 2:  # Buy
            if self.balance > current_price:
                self.shares_held = self.balance // current_price
                self.balance -= self.shares_held * current_price
                reward = self.shares_held * (self.df.iloc[self.current_step - 1]["Close"] - current_price)

        self.net_worth = self.balance + (self.shares_held * current_price)
        
        # Observation
        obs = self.df.iloc[self.current_step][features].values
        return obs, reward, done, {}

    def reset(self):
        self.current_step = 0
        self.balance = 10000
        self.shares_held = 0
        self.net_worth = self.balance
        return self.df.iloc[self.current_step][features].values

# Initialize and train PPO model
env = StockTradingEnv(df)
model = PPO("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=50000)

# Save the model
model.save("trained_models/ppo_trading_bot")
