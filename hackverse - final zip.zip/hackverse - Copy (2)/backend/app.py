from flask import Flask, jsonify, request
from flask_cors import CORS
import requests
import os
from dotenv import load_dotenv
from rl_agent import predict_trade  # Import the RL model's predict_trade function

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Alpha Vantage API key
ALPHA_VANTAGE_API_KEY = os.getenv("ALPHA_VANTAGE_API_KEY")

def get_stock_price(symbol):
    """Fetch real-time stock price using Alpha Vantage API."""
    url = f"https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={symbol}&interval=1min&apikey={ALPHA_VANTAGE_API_KEY}"
    print(f"Fetching real-time price for {symbol}...")
    response = requests.get(url)
    data = response.json()
    
    if "Time Series (1min)" in data:
        latest_time = next(iter(data["Time Series (1min)"]))
        latest_price = data["Time Series (1min)"][latest_time]["1. open"]
        print(f"Latest price for {symbol}: {latest_price}")
        return float(latest_price)
    else:
        print(f"Error fetching price: {data}")
        raise ValueError(f"Error fetching price: {data}")

def get_historical_data(symbol):
    """Fetch historical stock data using Alpha Vantage API."""
    url = f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&apikey={ALPHA_VANTAGE_API_KEY}"
    print(f"Fetching historical data for {symbol}...")
    response = requests.get(url)
    data = response.json()
    
    if "Time Series (Daily)" in data:
        historical_data = []
        for date, values in data["Time Series (Daily)"].items():
            historical_data.append({
                "Date": date,
                "Open": float(values["1. open"]),
                "High": float(values["2. high"]),
                "Low": float(values["3. low"]),
                "Close": float(values["4. close"]),
                "Volume": int(values["5. volume"]),
            })
        print(f"Fetched {len(historical_data)} days of historical data for {symbol}")
        return historical_data
    else:
        print(f"Error fetching historical data: {data}")
        raise ValueError(f"Error fetching historical data: {data}")

# Fetch stock price
@app.route("/stock/<symbol>", methods=["GET"])
def stock_price(symbol):
    """Fetch real-time stock price."""
    try:
        price = get_stock_price(symbol)
        return jsonify({"symbol": symbol, "price": price})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Suggest trade action using RL model
@app.route("/suggest/<symbol>", methods=["GET"])
def suggest(symbol):
    """Suggest trade action using RL model."""
    try:
        print(f"Fetching stock price for {symbol}...")
        price = get_stock_price(symbol)
        print(f"Price for {symbol}: {price}")
        
        # Create input data with all 8 features
        input_data = [
            price,  # Open
            price,  # High
            price,  # Low
            price,  # Close
            price,  # VWAP (use price as a placeholder)
            1000,   # Volume (dummy value)
            1000000,  # Turnover (dummy value)
            50      # %Deliverble (dummy value)
        ]
        
        print("Predicting trade action...")
        action = predict_trade(input_data)  # Use the RL model's predict_trade function
        print(f"Suggested action for {symbol}: {action}")
        
        return jsonify({"symbol": symbol, "suggestion": action})
    except Exception as e:
        print(f"Error in /suggest/{symbol}: {e}")
        return jsonify({"error": str(e)}), 500

# Fetch historical stock data
@app.route("/historical/<symbol>", methods=["GET"])
def historical_data(symbol):
    """Fetch historical stock data."""
    try:
        data = get_historical_data(symbol)
        return jsonify(data)
    except Exception as e:
        print(f"Error in /historical/{symbol}: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5000)